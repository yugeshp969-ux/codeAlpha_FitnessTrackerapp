import 'package:flutter/material.dart';

import '../models/activity_entry.dart';

const List<String> kWorkoutTypes = [
  'Walking',
  'Running',
  'Cycling',
  'Yoga',
  'Strength Training',
  'Swimming',
  'Other',
];

/// Form for logging a new day's fitness data. Pops with the created
/// [ActivityEntry], or null if the user cancels.
class LogEntryScreen extends StatefulWidget {
  const LogEntryScreen({super.key});

  @override
  State<LogEntryScreen> createState() => _LogEntryScreenState();
}

class _LogEntryScreenState extends State<LogEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _stepsController = TextEditingController();
  final _minutesController = TextEditingController();
  final _caloriesController = TextEditingController();

  DateTime _date = DateTime.now();
  String _workoutType = kWorkoutTypes.first;

  @override
  void dispose() {
    _stepsController.dispose();
    _minutesController.dispose();
    _caloriesController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _date,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now(),
    );
    if (picked != null) setState(() => _date = picked);
  }

  void _save() {
    if (!_formKey.currentState!.validate()) return;

    final entry = ActivityEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      date: _date,
      steps: int.parse(_stepsController.text.trim()),
      workoutType: _workoutType,
      workoutMinutes: int.parse(_minutesController.text.trim()),
      caloriesBurned: int.parse(_caloriesController.text.trim()),
    );

    Navigator.pop(context, entry);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Log Activity')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Date'),
              subtitle: Text('${_date.year}-${_date.month.toString().padLeft(2, '0')}-${_date.day.toString().padLeft(2, '0')}'),
              trailing: const Icon(Icons.calendar_today_outlined),
              onTap: _pickDate,
            ),
            const Divider(height: 24),
            TextFormField(
              controller: _stepsController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Steps',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.directions_walk),
              ),
              validator: (v) => _validateNonNegativeInt(v, 'steps'),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              initialValue: _workoutType,
              decoration: const InputDecoration(
                labelText: 'Workout type',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.fitness_center),
              ),
              items: kWorkoutTypes
                  .map((type) => DropdownMenuItem(value: type, child: Text(type)))
                  .toList(),
              onChanged: (value) => setState(() => _workoutType = value ?? _workoutType),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _minutesController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Workout duration (minutes)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.timer_outlined),
              ),
              validator: (v) => _validateNonNegativeInt(v, 'duration'),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _caloriesController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Calories burned',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.local_fire_department_outlined),
              ),
              validator: (v) => _validateNonNegativeInt(v, 'calories'),
            ),
            const SizedBox(height: 28),
            FilledButton(
              onPressed: _save,
              style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
              child: const Text('Save entry'),
            ),
          ],
        ),
      ),
    );
  }

  String? _validateNonNegativeInt(String? value, String fieldName) {
    if (value == null || value.trim().isEmpty) return 'Enter $fieldName';
    final parsed = int.tryParse(value.trim());
    if (parsed == null || parsed < 0) return 'Enter a valid $fieldName';
    return null;
  }
}
