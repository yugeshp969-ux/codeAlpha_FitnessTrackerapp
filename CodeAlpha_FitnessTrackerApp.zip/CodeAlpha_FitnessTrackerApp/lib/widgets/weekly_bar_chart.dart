import 'package:flutter/material.dart';

/// One bar in the weekly chart.
class WeeklyBarData {
  final String label;
  final double value;

  const WeeklyBarData({required this.label, required this.value});
}

/// A simple, dependency-free bar chart for showing steps (or any metric)
/// across the last 7 days.
class WeeklyBarChart extends StatelessWidget {
  final List<WeeklyBarData> data;
  final Color color;
  final double height;

  const WeeklyBarChart({
    super.key,
    required this.data,
    this.color = const Color(0xFF4F46E5),
    this.height = 160,
  });

  @override
  Widget build(BuildContext context) {
    final maxValue = data.map((d) => d.value).fold<double>(0, (a, b) => a > b ? a : b);
    final safeMax = maxValue <= 0 ? 1.0 : maxValue;

    return SizedBox(
      height: height,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: data.map((bar) {
          final barHeight = (bar.value / safeMax) * (height - 28);
          return Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    bar.value > 0 ? bar.value.toInt().toString() : '',
                    style: const TextStyle(fontSize: 10, color: Colors.black45),
                  ),
                  const SizedBox(height: 4),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 400),
                    curve: Curves.easeOut,
                    height: barHeight.clamp(2, height - 28),
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(6),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    bar.label,
                    style: const TextStyle(fontSize: 11, color: Colors.black54),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
