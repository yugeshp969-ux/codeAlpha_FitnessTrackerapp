/// A single manually logged fitness entry for one day.
class ActivityEntry {
  final String id;
  final DateTime date;
  final int steps;
  final String workoutType;
  final int workoutMinutes;
  final int caloriesBurned;

  const ActivityEntry({
    required this.id,
    required this.date,
    required this.steps,
    required this.workoutType,
    required this.workoutMinutes,
    required this.caloriesBurned,
  });

  /// Date with the time stripped off, used for grouping entries by day.
  DateTime get day => DateTime(date.year, date.month, date.day);

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'steps': steps,
        'workoutType': workoutType,
        'workoutMinutes': workoutMinutes,
        'caloriesBurned': caloriesBurned,
      };

  factory ActivityEntry.fromJson(Map<String, dynamic> json) => ActivityEntry(
        id: json['id'] as String,
        date: DateTime.parse(json['date'] as String),
        steps: json['steps'] as int,
        workoutType: json['workoutType'] as String,
        workoutMinutes: json['workoutMinutes'] as int,
        caloriesBurned: json['caloriesBurned'] as int,
      );
}
