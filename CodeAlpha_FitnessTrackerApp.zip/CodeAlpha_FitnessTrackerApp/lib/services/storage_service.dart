import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/activity_entry.dart';

/// Saves and loads fitness log entries on the device using shared_preferences.
/// All entries are stored as a single JSON array under one key.
class StorageService {
  static const String _storageKey = 'fitness_entries_v1';

  Future<List<ActivityEntry>> loadEntries() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);

    if (raw == null) {
      final seed = starterEntries();
      await saveEntries(seed);
      return seed;
    }

    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      final entries = decoded
          .map((e) => ActivityEntry.fromJson(e as Map<String, dynamic>))
          .toList();
      entries.sort((a, b) => b.date.compareTo(a.date));
      return entries;
    } catch (_) {
      return <ActivityEntry>[];
    }
  }

  Future<void> saveEntries(List<ActivityEntry> entries) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = jsonEncode(entries.map((e) => e.toJson()).toList());
    await prefs.setString(_storageKey, encoded);
  }

  /// A few sample entries from the past days so the dashboard isn't empty
  /// on first launch.
  static List<ActivityEntry> starterEntries() {
    final now = DateTime.now();
    DateTime daysAgo(int n) => now.subtract(Duration(days: n));

    return [
      ActivityEntry(
        id: 'seed-1',
        date: daysAgo(0),
        steps: 6200,
        workoutType: 'Walking',
        workoutMinutes: 30,
        caloriesBurned: 240,
      ),
      ActivityEntry(
        id: 'seed-2',
        date: daysAgo(1),
        steps: 8100,
        workoutType: 'Running',
        workoutMinutes: 25,
        caloriesBurned: 310,
      ),
      ActivityEntry(
        id: 'seed-3',
        date: daysAgo(2),
        steps: 3900,
        workoutType: 'Yoga',
        workoutMinutes: 40,
        caloriesBurned: 150,
      ),
    ];
  }
}
