# CodeAlpha_FitnessTrackerApp

Task 3 of the **CodeAlpha App Development Internship** — a fitness tracking app built with Flutter.

## Features

- Manually log daily fitness data: **steps**, **workout type**, **workout duration**, and **calories burned**
- **Dashboard** tab with today's summary stats, progress bars toward daily step/calorie goals, and a 7-day steps bar chart
- **History** tab listing all logged entries, newest first — swipe left to delete
- Data is saved on the device with `shared_preferences`, so it survives app restarts
- Clean, minimal Material 3 interface with cards and progress indicators

## Project structure

```
lib/
├── main.dart                     # App entry point and theme
├── models/
│   └── activity_entry.dart       # ActivityEntry model + JSON serialization
├── services/
│   └── storage_service.dart      # Local persistence (shared_preferences)
├── screens/
│   ├── home_screen.dart          # Dashboard + History tabs
│   └── log_entry_screen.dart     # Form to log a new day's activity
└── widgets/
    ├── stat_card.dart            # Summary stat tiles + goal progress bars
    └── weekly_bar_chart.dart     # Dependency-free 7-day bar chart
```

## Getting started

```bash
flutter create . --project-name codealpha_fitness_tracker_app   # generates android/ios/web folders
flutter pub get
flutter run
```

> The `flutter create .` step only needs to be run once, to generate the platform folders.
> `lib/` and `pubspec.yaml` in this repo are already set up — keep them as they are.

## Requirements

- Flutter SDK 3.0 or newer
- Dart 3.0 or newer

## How it works

Each logged day is stored as a JSON object (date, steps, workout type,
minutes, calories) inside a single JSON array under one `shared_preferences`
key. The dashboard aggregates today's entries for the summary stats and
groups the last 7 days for the weekly chart. On first launch the app seeds
three sample entries so the dashboard isn't empty.

## Daily goals

Default goals are 10,000 steps and 500 calories — adjustable in
`lib/screens/home_screen.dart` (`kDailyStepsGoal`, `kDailyCaloriesGoal`).

## Author

Built as part of the CodeAlpha App Development Internship.
