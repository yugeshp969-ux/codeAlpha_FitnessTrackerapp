import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/activity_entry.dart';
import '../services/storage_service.dart';
import '../widgets/stat_card.dart';
import '../widgets/weekly_bar_chart.dart';
import 'log_entry_screen.dart';

const int kDailyStepsGoal = 10000;
const int kDailyCaloriesGoal = 500;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StorageService _storage = StorageService();

  List<ActivityEntry> _entries = [];
  bool _loading = true;
  int _tabIndex = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final entries = await _storage.loadEntries();
    if (!mounted) return;
    setState(() {
      _entries = entries;
      _loading = false;
    });
  }

  Future<void> _addEntry() async {
    final created = await Navigator.push<ActivityEntry>(
      context,
      MaterialPageRoute(builder: (_) => const LogEntryScreen()),
    );
    if (created == null || !mounted) return;

    setState(() {
      _entries.insert(0, created);
      _entries.sort((a, b) => b.date.compareTo(a.date));
    });
    await _storage.saveEntries(_entries);
  }

  Future<void> _deleteEntry(ActivityEntry entry) async {
    setState(() => _entries.removeWhere((e) => e.id == entry.id));
    await _storage.saveEntries(_entries);
  }

  List<ActivityEntry> get _todayEntries {
    final today = DateTime.now();
    final todayDay = DateTime(today.year, today.month, today.day);
    return _entries.where((e) => e.day == todayDay).toList();
  }

  List<WeeklyBarData> get _weeklySteps {
    final today = DateTime.now();
    final days = List.generate(7, (i) => today.subtract(Duration(days: 6 - i)));

    return days.map((d) {
      final day = DateTime(d.year, d.month, d.day);
      final total = _entries
          .where((e) => e.day == day)
          .fold<int>(0, (sum, e) => sum + e.steps);
      return WeeklyBarData(label: DateFormat('E').format(d), value: total.toDouble());
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Fitness Tracker')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addEntry,
        icon: const Icon(Icons.add),
        label: const Text('Log activity'),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tabIndex,
        onDestinationSelected: (i) => setState(() => _tabIndex = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.history), label: 'History'),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _tabIndex == 0
              ? _buildDashboard()
              : _buildHistory(),
    );
  }

  Widget _buildDashboard() {
    final today = _todayEntries;
    final steps = today.fold<int>(0, (sum, e) => sum + e.steps);
    final calories = today.fold<int>(0, (sum, e) => sum + e.caloriesBurned);
    final minutes = today.fold<int>(0, (sum, e) => sum + e.workoutMinutes);

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Text(
          DateFormat('EEEE, MMM d').format(DateTime.now()),
          style: const TextStyle(fontSize: 15, color: Colors.black54, fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: StatCard(
                icon: Icons.directions_walk,
                value: '$steps',
                label: 'Steps today',
                color: const Color(0xFF4F46E5),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatCard(
                icon: Icons.local_fire_department_outlined,
                value: '$calories',
                label: 'Calories burned',
                color: const Color(0xFFEA580C),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: StatCard(
                icon: Icons.timer_outlined,
                value: '$minutes',
                label: 'Active minutes',
                color: const Color(0xFF059669),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Daily goals', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 16),
              GoalProgressBar(label: 'Steps', current: steps, goal: kDailyStepsGoal, color: const Color(0xFF4F46E5)),
              const SizedBox(height: 16),
              GoalProgressBar(label: 'Calories', current: calories, goal: kDailyCaloriesGoal, color: const Color(0xFFEA580C)),
            ],
          ),
        ),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 12, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Steps this week', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 16),
              WeeklyBarChart(data: _weeklySteps),
            ],
          ),
        ),
        const SizedBox(height: 80),
      ],
    );
  }

  Widget _buildHistory() {
    if (_entries.isEmpty) {
      return const Center(
        child: Text('No entries yet. Tap "Log activity" to add one.', style: TextStyle(color: Colors.black54)),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
      itemCount: _entries.length,
      itemBuilder: (context, index) {
        final entry = _entries[index];
        return Dismissible(
          key: ValueKey(entry.id),
          direction: DismissDirection.endToStart,
          background: Container(
            alignment: Alignment.centerRight,
            padding: const EdgeInsets.only(right: 20),
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(color: Colors.red.shade400, borderRadius: BorderRadius.circular(14)),
            child: const Icon(Icons.delete_outline, color: Colors.white),
          ),
          onDismissed: (_) => _deleteEntry(entry),
          child: Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 3)),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: const Color(0xFF4F46E5).withOpacity(0.12),
                  child: const Icon(Icons.fitness_center, color: Color(0xFF4F46E5)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${entry.workoutType} · ${entry.workoutMinutes} min',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        DateFormat('EEE, MMM d').format(entry.date),
                        style: const TextStyle(fontSize: 12, color: Colors.black54),
                      ),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text('${entry.steps} steps', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                    Text('${entry.caloriesBurned} kcal', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
